import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useVideoConfig} from 'remotion';

const mono = 'JetBrains Mono, monospace';
const sans = 'DM Sans, system-ui, sans-serif';

type Props = {frame:number};

const seg = {
  intro:[0,90],
  ocean:[90,210],
  unity:[210,330],
  reverse:[330,450],
  rdna:[450,570],
  cuda:[570,690],
  fusion:[690,840],
  final:[840,990],
} as const;

const pal = {
  cyber: {accent:'#77dbff', accent2:'#ff76ce', grad:'linear-gradient(135deg,#eff7ff 0%,#7adfff 44%,#8f65ff 100%)', subtle:'#a7c0db'},
  ocean: {accent:'#6be6ff', accent2:'#2ab2e8', grad:'linear-gradient(135deg,#d8f9ff 0%,#79e6ff 36%,#29bfe8 100%)', subtle:'#9db8ca'},
  unity: {accent:'#f0c18f', accent2:'#bf7f45', grad:'linear-gradient(135deg,#fff1d9 0%,#f0c18f 38%,#9d6333 100%)', subtle:'#d3beaa'},
  ice: {accent:'#dcefff', accent2:'#7db9ff', grad:'linear-gradient(135deg,#ffffff 0%,#dcefff 34%,#7db9ff 100%)', subtle:'#b7c8d8'},
  volcano: {accent:'#ff6d56', accent2:'#ffca8b', grad:'linear-gradient(135deg,#ffd4b0 0%,#ff7b58 38%,#d92b2b 100%)', subtle:'#d9a79d'},
  forest: {accent:'#8ff6a8', accent2:'#35bc6a', grad:'linear-gradient(135deg,#f0fff3 0%,#8ff6a8 36%,#33bc69 100%)', subtle:'#b8ceb8'},
  fusion: {accent:'#79e7ff', accent2:'#ff6f6f', grad:'linear-gradient(135deg,#edf9ff 0%,#6bf0b1 30%,#79e7ff 58%,#ff6f6f 100%)', subtle:'#bac9df'},
};

const fade = (frame:number, start:number, end:number, pad=14) => interpolate(frame, [start, start + pad, end - pad, end], [0,1,1,0], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
const slideY = (frame:number, start:number, end:number, from=24) => interpolate(frame, [start, end], [from, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp', easing:Easing.out(Easing.cubic)});
const slideX = (frame:number, start:number, end:number, from=24) => interpolate(frame, [start, end], [from, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp', easing:Easing.out(Easing.cubic)});

const Chip: React.FC<{text:string;color:string;frame:number;start:number;width?:number;dir?:number}> = ({text,color,frame,start,width=220,dir=1}) => {
  const alpha = fade(frame, start, start + 56, 10);
  const y = slideY(frame, start, start + 12, 16);
  const x = slideX(frame, start, start + 12, dir * 22);
  return (
    <div style={{minWidth:width, padding:'12px 20px', borderRadius:16, border:`1px solid ${color}33`, background:'rgba(6,12,20,0.56)', boxShadow:'0 14px 34px rgba(0,0,0,0.18)', fontFamily:mono, fontSize:21, letterSpacing:'0.11em', color, textTransform:'uppercase', textAlign:'center', transform:`translate(${x}px, ${y}px)`, opacity:alpha, backdropFilter:'blur(4px)'}}>
      {text}
    </div>
  );
};

export const TextOverlay: React.FC<Props> = ({frame}) => {
  const {fps} = useVideoConfig();
  const finalSpring = spring({fps, frame: frame - seg.final[0] + 6, config:{damping:180, stiffness:80}});
  const beatPulse = 1 + Math.max(0, Math.sin(frame * 0.18)) * 0.06;

  return (
    <AbsoluteFill style={{pointerEvents:'none'}}>
      {frame < seg.ocean[0] && (
        <div style={{position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', opacity:fade(frame, seg.intro[0], seg.intro[1], 18)}}>
          <div style={{position:'relative', width:220, height:220, marginBottom:26, transform:`scale(${beatPulse})`, opacity:0.9}}>
            <div style={{position:'absolute', inset:0, borderRadius:'50%', border:'2px solid rgba(119,219,255,0.46)', boxShadow:'0 0 50px rgba(119,219,255,0.14)'}} />
            <div style={{position:'absolute', inset:22, borderRadius:'50%', border:'1px solid rgba(255,118,206,0.24)'}} />
            <div style={{position:'absolute', inset:56, borderRadius:'50%', border:'1px solid rgba(119,219,255,0.24)'}} />
            <div style={{position:'absolute', top:'50%', left:'50%', width:18, height:18, borderRadius:'50%', transform:'translate(-50%, -50%)', background:'rgba(239,247,255,0.95)', boxShadow:'0 0 20px rgba(119,219,255,0.4)'}} />
            <div style={{position:'absolute', top:'50%', left:12, right:12, height:2, background:'linear-gradient(90deg, transparent 0%, rgba(119,219,255,0.0) 12%, rgba(119,219,255,0.34) 48%, rgba(119,219,255,0.0) 88%, transparent 100%)'}} />
          </div>
          <div style={{fontFamily:mono, fontSize:14, letterSpacing:'0.28em', color:pal.cyber.accent, textTransform:'uppercase', marginBottom:18}}>signal acquired</div>
          <div style={{fontFamily:sans, fontSize:72, lineHeight:0.94, fontWeight:700, letterSpacing:'-0.05em', color:'#edf6ff', textAlign:'center', transform:`translateY(${slideY(frame, 0, 24, 18)}px)`}}>LOADING USER DATA,</div>
          <div style={{fontFamily:sans, fontSize:72, lineHeight:0.94, fontWeight:700, letterSpacing:'-0.05em', background:pal.cyber.grad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text', textAlign:'center', transform:`translateY(${slideY(frame, 8, 30, 14)}px)`}}>COMMENCING ANALYSIS</div>
        </div>
      )}

      {frame >= seg.ocean[0] && frame < seg.ocean[1] && (
        <Centered
          frame={frame}
          start={seg.ocean[0]}
          end={seg.ocean[1]}
          kicker="pelagic systems"
          line1="LAYERED SYSTEMS"
          line2="IN MOTION"
          sub="oceanic depth · rendering feel · controlled atmosphere"
          theme={pal.ocean}
        />
      )}

      {frame >= seg.unity[0] && frame < seg.unity[1] && (
        <Centered
          frame={frame}
          start={seg.unity[0]}
          end={seg.unity[1]}
          kicker="mountain engine chamber"
          line1="UNITY"
          line2="UE5"
          sub="real-time worlds · gameplay systems"
          theme={pal.unity}
          extra={<div style={{marginTop:24, display:'flex', gap:16}}><Chip text="Unity" color={pal.unity.accent} frame={frame} start={seg.unity[0] + 18} width={180} dir={-1} /><Chip text="Unreal Engine 5" color="#fff3e1" frame={frame} start={seg.unity[0] + 32} width={320} dir={1} /></div>}
        />
      )}

      {frame >= seg.reverse[0] && frame < seg.reverse[1] && (
        <div style={{position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', opacity:fade(frame, seg.reverse[0], seg.reverse[1], 16), transform:`translateY(${slideY(frame, seg.reverse[0], seg.reverse[0] + 12, 18)}px)`}}>
          <div style={{fontFamily:mono, fontSize:14, letterSpacing:'0.28em', color:pal.ice.accent, textTransform:'uppercase', marginBottom:18}}>glacial inspection</div>
          <div style={{fontFamily:sans, fontSize:104, lineHeight:0.92, fontWeight:700, letterSpacing:'-0.055em', color:'#f4f8fb'}}>REVERSE</div>
          <div style={{fontFamily:sans, fontSize:104, lineHeight:0.92, fontWeight:700, letterSpacing:'-0.055em', background:pal.ice.grad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'}}>ENGINEERING</div>
          <div style={{marginTop:24, fontFamily:mono, fontSize:16, letterSpacing:'0.12em', color:pal.ice.subtle, textTransform:'uppercase'}}>ghidra · hxd · wireshark · systems analysis</div>
          <div style={{marginTop:26, display:'flex', gap:16, flexWrap:'wrap', justifyContent:'center'}}>
            <Chip text="Ghidra" color={pal.ice.accent} frame={frame} start={seg.reverse[0] + 16} width={180} dir={-1} />
            <Chip text="Binary Analysis" color="#eff9ff" frame={frame} start={seg.reverse[0] + 30} width={260} dir={1} />
            <Chip text="Protocol Tracing" color="#eff9ff" frame={frame} start={seg.reverse[0] + 44} width={280} dir={-1} />
          </div>
        </div>
      )}

      {frame >= seg.rdna[0] && frame < seg.rdna[1] && (
        <Centered
          frame={frame}
          start={seg.rdna[0]}
          end={seg.rdna[1]}
          kicker="volcanic subsystem"
          line1="RDNA"
          line2="ARCHITECTURE"
          sub="low-level performance · gpu systems"
          theme={pal.volcano}
        />
      )}

      {frame >= seg.cuda[0] && frame < seg.cuda[1] && (
        <Centered
          frame={frame}
          start={seg.cuda[0]}
          end={seg.cuda[1]}
          kicker="forest compute"
          line1="CUDA"
          line2="PARALLEL THINKING"
          sub="compute · tooling · systems"
          theme={pal.forest}
        />
      )}

      {frame >= seg.fusion[0] && frame < seg.fusion[1] && (
        <div style={{position:'absolute', inset:0, opacity:fade(frame, seg.fusion[0], seg.fusion[1], 18)}}>
          <div style={{position:'absolute', top:'14%', left:'50%', transform:'translateX(-50%)', fontFamily:mono, fontSize:14, letterSpacing:'0.24em', color:pal.fusion.accent, textTransform:'uppercase'}}>synthesis archive</div>
          <div style={{position:'absolute', left:'8%', top:'28%', display:'flex', flexDirection:'column', gap:18}}>
            <Chip text="DONGHUA-CLI" color={pal.fusion.accent} frame={frame} start={seg.fusion[0] + 10} width={320} dir={-1} />
            <Chip text="BITBYBIT" color="#f1f6ff" frame={frame} start={seg.fusion[0] + 22} width={240} dir={1} />
            <Chip text="CROW-B3" color={pal.fusion.accent2} frame={frame} start={seg.fusion[0] + 34} width={220} dir={-1} />
          </div>
          <div style={{position:'absolute', right:'8%', top:'28%', display:'flex', flexDirection:'column', gap:18}}>
            <Chip text="C++" color="#f1f6ff" frame={frame} start={seg.fusion[0] + 16} width={160} dir={1} />
            <Chip text="PYTHON" color={pal.fusion.accent} frame={frame} start={seg.fusion[0] + 28} width={180} dir={-1} />
            <Chip text="GRAPHICS" color={pal.fusion.accent2} frame={frame} start={seg.fusion[0] + 40} width={210} dir={1} />
            <Chip text="OPEN SOURCE" color="#f1f6ff" frame={frame} start={seg.fusion[0] + 52} width={240} dir={-1} />
          </div>
          <div style={{position:'absolute', left:'50%', top:'36%', transform:'translateX(-50%)', textAlign:'center', opacity:fade(frame, seg.fusion[0] + 8, seg.fusion[1], 12)}}>
            <div style={{fontFamily:sans, fontSize:74, fontWeight:700, letterSpacing:'-0.05em', color:'#edf5fb'}}>BUILT LIKE</div>
            <div style={{fontFamily:sans, fontSize:88, fontWeight:700, letterSpacing:'-0.055em', background:pal.fusion.grad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'}}>A WORLD</div>
            <div style={{marginTop:18, fontFamily:mono, fontSize:16, letterSpacing:'0.12em', color:pal.fusion.subtle, textTransform:'uppercase'}}>systems · style · motion · tooling</div>
          </div>
        </div>
      )}

      {frame >= seg.final[0] && (
        <div style={{position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', opacity:fade(frame, seg.final[0], seg.final[1], 18), transform:`scale(${0.94 + finalSpring * 0.06}) translateY(${slideY(frame, seg.final[0], seg.final[0] + 18, 20)}px)`}}>
          <div style={{fontFamily:mono, fontSize:14, letterSpacing:'0.28em', color:pal.ocean.accent, textTransform:'uppercase', marginBottom:18}}>final signal</div>
          <div style={{fontFamily:sans, fontSize:126, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', color:'#edf7fc'}}>THANUKA</div>
          <div style={{fontFamily:sans, fontSize:126, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', background:pal.ocean.grad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'}}>PERERA</div>
          <div style={{marginTop:24, fontFamily:mono, fontSize:16, letterSpacing:'0.12em', color:pal.ocean.subtle, textTransform:'uppercase'}}>GAME DEVELOPER · GPU ARCHITECTURE · SYSTEMS ENGINEER</div>
          <div style={{marginTop:18, fontFamily:mono, fontSize:22, letterSpacing:'0.06em', color:pal.ocean.accent}}>thanukamax.github.io</div>
        </div>
      )}
    </AbsoluteFill>
  );
};

const Centered: React.FC<{theme:any; frame:number; start:number; end:number; kicker:string; line1:string; line2:string; sub:string; extra?:React.ReactNode}> = ({theme, frame, start, end, kicker, line1, line2, sub, extra}) => (
  <div style={{position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', opacity:fade(frame, start, end, 16), transform:`translateY(${slideY(frame, start, start + 12, 22)}px)`}}>
    <div style={{fontFamily:mono, fontSize:14, letterSpacing:'0.28em', color:theme.accent, textTransform:'uppercase', marginBottom:18}}>{kicker}</div>
    <div style={{fontFamily:sans, fontSize:108, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', color:'#f4f8fb'}}>{line1}</div>
    <div style={{fontFamily:sans, fontSize:108, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', background:theme.grad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'}}>{line2}</div>
    <div style={{marginTop:24, fontFamily:mono, fontSize:16, letterSpacing:'0.12em', color:theme.subtle, textTransform:'uppercase'}}>{sub}</div>
    {extra}
  </div>
);
