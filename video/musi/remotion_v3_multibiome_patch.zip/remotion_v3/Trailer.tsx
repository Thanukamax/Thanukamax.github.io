import React from 'react';
import {AbsoluteFill, Audio, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Biome, SceneBackground} from './SceneBackground';
import {SceneForeground} from './SceneForeground';
import {Particles} from './Particles';
import {TextOverlay} from './TextOverlay';

const sceneMap = [
  {start:0, end:90, biome:'ocean' as Biome},
  {start:90, end:180, biome:'ocean' as Biome},
  {start:180, end:300, biome:'ocean' as Biome},
  {start:300, end:420, biome:'volcano' as Biome},
  {start:420, end:540, biome:'forest' as Biome},
  {start:540, end:660, biome:'mountain' as Biome},
  {start:660, end:780, biome:'archive' as Biome},
  {start:780, end:840, biome:'oceanFinal' as Biome},
];

const sceneOpacity = (frame:number, start:number, end:number, fadeIn=14, fadeOut=16) => {
  if (start === 0) {
    return interpolate(frame, [start, start + fadeIn, end - fadeOut, end], [1, 1, 1, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
  }
  if (end === 840) {
    return interpolate(frame, [start, start + fadeIn, end], [0, 1, 1], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
  }
  return interpolate(frame, [start, start + fadeIn, end - fadeOut, end], [0, 1, 1, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
};

const pulse = (frame:number, center:number, width:number, amount:number) => {
  return interpolate(frame, [center - width, center, center + width], [0, amount, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
};

const transitionBoundaries = [300, 420, 540, 660, 780];

const colorForBiome = (biome: Biome) => {
  switch (biome) {
    case 'ocean':
    case 'oceanFinal':
      return '98,224,255';
    case 'volcano':
      return '255,90,70';
    case 'forest':
      return '102,236,135';
    case 'mountain':
      return '192,214,255';
    default:
      return '121,150,255';
  }
};

const TransitionOverlay: React.FC<{frame:number; boundary:number; color:string}> = ({frame, boundary, color}) => {
  const op = pulse(frame, boundary, 12, 1);
  const x = interpolate(frame, [boundary - 10, boundary + 10], [-55, 55], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
  return (
    <div
      style={{
        position:'absolute',
        inset:'-10% -20%',
        pointerEvents:'none',
        opacity:op * 0.9,
        transform:`translateX(${x}%) rotate(-8deg)`,
        background:`linear-gradient(90deg, transparent 0%, rgba(${color},0.05) 24%, rgba(${color},0.18) 50%, rgba(${color},0.05) 76%, transparent 100%)`,
        filter:'blur(24px)',
        mixBlendMode:'screen',
      }}
    />
  );
};

export const Trailer: React.FC = () => {
  const frame = useCurrentFrame();

  const driftX = Math.sin(frame * 0.01) * 6;
  const driftY = Math.cos(frame * 0.008) * 4;
  const push = interpolate(frame, [0, 840], [1.015, 1.0], {extrapolateRight:'clamp'});
  const whipX = transitionBoundaries.reduce((acc, boundary, idx) => acc + pulse(frame, boundary, 10, idx % 2 === 0 ? -34 : 34), 0);
  const whipY = transitionBoundaries.reduce((acc, boundary) => acc + pulse(frame, boundary, 12, -10), 0);
  const whipRot = transitionBoundaries.reduce((acc, boundary, idx) => acc + pulse(frame, boundary, 10, idx % 2 === 0 ? -1.2 : 1.2), 0);

  return (
    <AbsoluteFill style={{backgroundColor:'#02060f', overflow:'hidden'}}>
      <Audio src={staticFile('music.mp3')} volume={0.92} />

      <AbsoluteFill style={{transform:`translate(${driftX + whipX * 0.18}px, ${driftY + whipY * 0.16}px) scale(${push}) rotate(${whipRot * 0.15}deg)`}}>
        {sceneMap.map((scene) => {
          const localFrame = Math.max(0, frame - scene.start);
          const opacity = sceneOpacity(frame, scene.start, scene.end);
          return (
            <AbsoluteFill key={`${scene.start}-${scene.biome}`}>
              <SceneBackground biome={scene.biome} frame={localFrame} opacity={opacity} />
            </AbsoluteFill>
          );
        })}
      </AbsoluteFill>

      <AbsoluteFill style={{transform:`translate(${driftX * 0.65 + whipX * 0.4}px, ${driftY * 0.4 + whipY * 0.28}px) rotate(${whipRot * 0.3}deg)`}}>
        {sceneMap.map((scene) => {
          const localFrame = Math.max(0, frame - scene.start);
          const opacity = sceneOpacity(frame, scene.start, scene.end);
          return (
            <AbsoluteFill key={`p-${scene.start}-${scene.biome}`}>
              <Particles biome={scene.biome} frame={localFrame} opacity={opacity} />
            </AbsoluteFill>
          );
        })}
      </AbsoluteFill>

      <AbsoluteFill style={{transform:`translate(${driftX * 0.24 + whipX * 0.08}px, ${driftY * 0.16 + whipY * 0.08}px)`}}>
        <TextOverlay frame={frame} />
      </AbsoluteFill>

      <AbsoluteFill style={{transform:`translate(${driftX * 0.85 + whipX * 0.65}px, ${driftY * 0.55 + whipY * 0.44}px) scale(1.03) rotate(${whipRot * 0.4}deg)`}}>
        {sceneMap.map((scene) => {
          const localFrame = Math.max(0, frame - scene.start);
          const opacity = sceneOpacity(frame, scene.start, scene.end);
          return (
            <AbsoluteFill key={`f-${scene.start}-${scene.biome}`}>
              <SceneForeground biome={scene.biome} frame={localFrame} opacity={opacity} />
            </AbsoluteFill>
          );
        })}
      </AbsoluteFill>

      {transitionBoundaries.map((boundary) => {
        const nextBiome = sceneMap.find((scene) => scene.start === boundary)?.biome ?? 'ocean';
        return <TransitionOverlay key={boundary} frame={frame} boundary={boundary} color={colorForBiome(nextBiome)} />;
      })}

      <div style={{position:'absolute', inset:0, background:'radial-gradient(ellipse 78% 72% at 50% 46%, transparent 36%, rgba(1,4,10,0.16) 66%, rgba(1,4,10,0.52) 100%)', pointerEvents:'none'}} />
      <div style={{position:'absolute', inset:'auto -8% -8% -8%', height:'30%', background:'linear-gradient(180deg, transparent 0%, rgba(1,4,10,0.16) 30%, rgba(1,4,10,0.58) 100%)', filter:'blur(8px)', pointerEvents:'none'}} />
    </AbsoluteFill>
  );
};
