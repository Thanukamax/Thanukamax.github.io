import React, {useMemo} from 'react';
import {AbsoluteFill} from 'remotion';
import {Biome} from './SceneBackground';

type Props = {
  biome: Biome;
  frame: number;
  opacity?: number;
};

type Mote = {x:number;y:number;size:number;speed:number;phase:number;alpha:number};

const buildMotes = (count:number) => {
  const arr:Mote[] = [];
  for (let i=0;i<count;i++) {
    const n = i * 87.133;
    arr.push({
      x: (n * 3.1) % 100,
      y: (n * 5.7) % 110,
      size: 1 + ((n * 1.4) % 3.8),
      speed: 0.5 + ((n * 0.25) % 1.3),
      phase: (n * 0.44) % 6.28,
      alpha: 0.12 + ((n * 0.19) % 0.32),
    });
  }
  return arr;
};

const palette = (biome: Biome) => {
  switch (biome) {
    case 'ocean':
      return {rgb:'134,227,255', streak:'95,210,255'};
    case 'oceanFinal':
      return {rgb:'194,244,255', streak:'110,222,255'};
    case 'volcano':
      return {rgb:'255,118,82', streak:'255,70,60'};
    case 'forest':
      return {rgb:'144,255,170', streak:'86,224,122'};
    case 'mountain':
      return {rgb:'206,224,255', streak:'160,196,255'};
    default:
      return {rgb:'160,216,255', streak:'118,138,255'};
  }
};

export const Particles: React.FC<Props> = ({biome, frame, opacity = 1}) => {
  const items = useMemo(() => buildMotes(68), []);
  const pal = palette(biome);
  const speedFactor = biome === 'volcano' ? 1.15 : biome === 'forest' ? 0.72 : 0.9;

  return (
    <AbsoluteFill style={{opacity, pointerEvents:'none'}}>
      {items.map((m, i) => {
        const rise = frame * (0.15 + m.speed * 0.08) * speedFactor;
        const x = m.x + Math.sin(frame * 0.012 + m.phase) * (i % 5 === 0 ? 7 : 3);
        const y = ((m.y - rise) % 116 + 116) % 116 - 8;
        const op = m.alpha * (0.54 + Math.sin(frame * 0.03 + m.phase) * 0.24);
        return (
          <div
            key={i}
            style={{
              position:'absolute',
              left:`${x}%`,
              top:`${y}%`,
              width:m.size,
              height:m.size,
              borderRadius:'50%',
              background:`rgba(${pal.rgb},${op})`,
              filter:'blur(0.4px)',
            }}
          />
        );
      })}

      <div
        style={{
          position:'absolute',
          inset:'-12% -12% 0 -12%',
          background: `
            linear-gradient(112deg, transparent 4%, rgba(${pal.streak},0.04) 28%, transparent 52%),
            linear-gradient(90deg, transparent 18%, rgba(${pal.streak},0.025) 36%, transparent 62%)
          `,
          transform:`translateX(${Math.sin(frame * 0.011) * 120}px) translateY(${Math.cos(frame * 0.009) * 18}px)`,
          filter:'blur(10px)',
          opacity: biome === 'volcano' ? 0.45 : 0.58,
        }}
      />

      {biome === 'ocean' || biome === 'oceanFinal' ? (
        <div style={{position:'absolute', inset:0, background:`radial-gradient(ellipse 80% 34% at 50% 14%, rgba(${pal.streak},0.06) 0%, transparent 56%)`, filter:'blur(18px)', opacity:0.7}} />
      ) : null}

      {biome === 'volcano' ? (
        <>
          {[0,1,2].map((i)=>(
            <div key={i} style={{position:'absolute', left:`${14 + i*26}%`, top:`${18 + i*10}%`, width:180 + i*80, height:40 + i*10, background:`rgba(${pal.streak},${0.05 + i*0.01})`, filter:'blur(20px)', transform:`rotate(${i===1?-12:9}deg) translateX(${Math.sin(frame * 0.016 + i) * 12}px)`}} />
          ))}
        </>
      ) : null}

      {biome === 'forest' ? (
        <>
          {[0,1,2].map((i)=>(
            <div key={i} style={{position:'absolute', left:`${12 + i*26}%`, top:`${14 + i*12}%`, width:150 + i*60, height:'72%', background:`linear-gradient(180deg, rgba(${pal.streak},0.07) 0%, rgba(${pal.streak},0.02) 22%, transparent 76%)`, filter:'blur(22px)', transform:`skewX(${i===1?-5:4}deg) translateX(${Math.sin(frame * 0.014 + i) * 10}px)`}} />
          ))}
        </>
      ) : null}
    </AbsoluteFill>
  );
};
