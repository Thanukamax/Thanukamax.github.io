import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useVideoConfig} from 'remotion';

const mono = 'JetBrains Mono, monospace';
const sans = 'DM Sans, system-ui, sans-serif';

type Props = {frame:number};

const seg = {
  intro:[0,90],
  name:[90,180],
  roles:[180,300],
  rdna:[300,420],
  cuda:[420,540],
  stack:[540,660],
  builds:[660,780],
  final:[780,840],
} as const;

const pal = {
  ocean: {accent:'#6be6ff', accentGrad:'linear-gradient(135deg,#d8f9ff 0%,#79e6ff 36%,#29bfe8 100%)', subtle:'#9db8ca'},
  volcano: {accent:'#ff6556', accentGrad:'linear-gradient(135deg,#ffd1ab 0%,#ff7a5a 34%,#db2727 100%)', subtle:'#d4a49a'},
  forest: {accent:'#8ff6a8', accentGrad:'linear-gradient(135deg,#f0fff3 0%,#8ff6a8 36%,#33bc69 100%)', subtle:'#b8ceb8'},
  mountain: {accent:'#dce8ff', accentGrad:'linear-gradient(135deg,#f7fbff 0%,#dce8ff 38%,#8cb3f2 100%)', subtle:'#afbdd2'},
  archive: {accent:'#a3b4ff', accentGrad:'linear-gradient(135deg,#edf3ff 0%,#a7bcff 36%,#5f7bff 100%)', subtle:'#b6c3df'},
};

const clampFade = (frame:number, start:number, end:number, fade=12) => interpolate(frame, [start, start + fade, end - fade, end], [0,1,1,0], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
const slideY = (frame:number, start:number, end:number, from=20) => interpolate(frame, [start, end], [from, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp', easing:Easing.out(Easing.cubic)});
const slideX = (frame:number, start:number, end:number, from=20) => interpolate(frame, [start, end], [from, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp', easing:Easing.out(Easing.cubic)});

const LabelChip: React.FC<{text:string;color:string;w?:number;frame:number;start:number;idx?:number}> = ({text,color,w=220,frame,start,idx=0}) => {
  const alpha = clampFade(frame,start,start + 40,10);
  const y = slideY(frame,start,start + 10,18 + idx * 2);
  const x = slideX(frame,start,start + 10, idx % 2 === 0 ? -24 : 24);
  return (
    <div style={{
      minWidth:w,
      padding:'12px 20px',
      borderRadius:14,
      border:`1px solid ${color}33`,
      background:'rgba(6,12,20,0.56)',
      boxShadow:'0 16px 40px rgba(0,0,0,0.18)',
      fontFamily:mono,
      fontSize:22,
      letterSpacing:'0.12em',
      color,
      textTransform:'uppercase',
      textAlign:'center',
      transform:`translate(${x}px, ${y}px)`,
      opacity:alpha,
      backdropFilter:'blur(4px)',
    }}>{text}</div>
  );
};

export const TextOverlay: React.FC<Props> = ({frame}) => {
  const {fps} = useVideoConfig();
  const nameSpring = spring({fps, frame: frame - seg.name[0] + 4, config:{damping:200, stiffness:90}});
  const finalSpring = spring({fps, frame: frame - seg.final[0] + 6, config:{damping:200, stiffness:90}});

  return (
    <AbsoluteFill style={{pointerEvents:'none'}}>
      {frame < seg.name[0] && (
        <div style={{position:'absolute', top:'28%', left:'50%', transform:'translateX(-50%)', fontFamily:mono, fontSize:14, letterSpacing:'0.28em', color:`${pal.ocean.accent}`, opacity:clampFade(frame,0,90,24)}}>
          SIGNAL ACQUIRED
        </div>
      )}

      {frame >= seg.name[0] && frame < seg.name[1] && (
        <div style={{position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', opacity:clampFade(frame, seg.name[0], seg.name[1], 16), transform:`translateY(${slideY(frame, seg.name[0], seg.name[0] + 18, 28)}px) scale(${0.92 + nameSpring * 0.08})`}}>
          <div style={{fontFamily:mono, fontSize:14, letterSpacing:'0.30em', color:pal.ocean.accent, textTransform:'uppercase', marginBottom:18}}>pelagic signal</div>
          <div style={{fontFamily:sans, fontSize:124, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', color:'#edf7fc'}}>THANUKA</div>
          <div style={{fontFamily:sans, fontSize:124, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', background:pal.ocean.accentGrad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'}}>PERERA</div>
          <div style={{marginTop:28, fontFamily:mono, fontSize:16, letterSpacing:'0.14em', color:pal.ocean.subtle, textTransform:'uppercase'}}>submerged systems observatory</div>
        </div>
      )}

      {frame >= seg.roles[0] && frame < seg.roles[1] && (
        <div style={{position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', opacity:clampFade(frame, seg.roles[0], seg.roles[1], 16)}}>
          <div style={{fontFamily:mono, fontSize:14, letterSpacing:'0.24em', color:pal.ocean.accent, textTransform:'uppercase', marginBottom:18, transform:`translateY(${slideY(frame, seg.roles[0], seg.roles[0] + 12, 16)}px)`}}>identity lock</div>
          <div style={{display:'flex', gap:16, alignItems:'center', flexWrap:'wrap', justifyContent:'center'}}>
            {['GAME DEVELOPER','GPU ARCHITECTURE','SYSTEMS ENGINEER'].map((t, i)=>(
              <div key={t} style={{fontFamily:mono, fontSize:22, letterSpacing:'0.12em', color:i===1?pal.ocean.accent:'#d7e8f4', textTransform:'uppercase', transform:`translateY(${slideY(frame, seg.roles[0] + i*12, seg.roles[0] + 10 + i*12, 18)}px)`, opacity:clampFade(frame, seg.roles[0] + i*10, seg.roles[1], 12)}}>{t}</div>
            ))}
          </div>
          <div style={{marginTop:34, display:'flex', gap:16}}>
            <LabelChip text="rendering" color={pal.ocean.accent} frame={frame} start={seg.roles[0] + 34} w={190} />
            <LabelChip text="systems" color="#dbeaf4" frame={frame} start={seg.roles[0] + 48} w={170} idx={1} />
            <LabelChip text="reverse engineering" color="#dbeaf4" frame={frame} start={seg.roles[0] + 62} w={330} idx={2} />
          </div>
        </div>
      )}

      {frame >= seg.rdna[0] && frame < seg.rdna[1] && (
        <CenteredBlock
          theme={pal.volcano}
          frame={frame}
          start={seg.rdna[0]}
          end={seg.rdna[1]}
          kicker="volcanic subsystem"
          titleA="RDNA"
          titleB="ARCHITECTURE"
          sub="low-level performance · gpu systems"
        />
      )}

      {frame >= seg.cuda[0] && frame < seg.cuda[1] && (
        <CenteredBlock
          theme={pal.forest}
          frame={frame}
          start={seg.cuda[0]}
          end={seg.cuda[1]}
          kicker="forest compute"
          titleA="CUDA"
          titleB="PARALLEL THINKING"
          sub="compute · tooling · systems"
        />
      )}

      {frame >= seg.stack[0] && frame < seg.stack[1] && (
        <div style={{position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', opacity:clampFade(frame, seg.stack[0], seg.stack[1], 16)}}>
          <div style={{width:1200, display:'grid', gridTemplateColumns:'1fr 1fr', gap:42, alignItems:'center'}}>
            <div>
              <div style={{fontFamily:mono, fontSize:14, letterSpacing:'0.24em', textTransform:'uppercase', color:pal.mountain.accent, marginBottom:20, transform:`translateY(${slideY(frame, seg.stack[0], seg.stack[0] + 12, 18)}px)`}}>alpine stack</div>
              <div style={{fontFamily:sans, fontSize:94, lineHeight:0.92, fontWeight:700, letterSpacing:'-0.05em', color:'#eef5fc'}}>TECH</div>
              <div style={{fontFamily:sans, fontSize:94, lineHeight:0.92, fontWeight:700, letterSpacing:'-0.05em', background:pal.mountain.accentGrad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'}}>STACK</div>
            </div>
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:18}}>
              {[
                ['C++', seg.stack[0] + 18],
                ['PYTHON', seg.stack[0] + 30],
                ['GRAPHICS', seg.stack[0] + 42],
                ['OPEN SOURCE', seg.stack[0] + 54],
              ].map(([text, start], idx)=><LabelChip key={text as string} text={text as string} color={idx<2?pal.mountain.accent:'#eef5fc'} frame={frame} start={start as number} w={260} idx={idx} />)}
            </div>
          </div>
        </div>
      )}

      {frame >= seg.builds[0] && frame < seg.builds[1] && (
        <div style={{position:'absolute', inset:0, opacity:clampFade(frame, seg.builds[0], seg.builds[1], 16)}}>
          <div style={{position:'absolute', top:'16%', left:'50%', transform:'translateX(-50%)', fontFamily:mono, fontSize:14, letterSpacing:'0.24em', color:pal.archive.accent, textTransform:'uppercase'}}>build archive</div>
          <div style={{position:'absolute', left:'12%', top:'32%', display:'flex', flexDirection:'column', gap:20}}>
            <LabelChip text="DONGHUA-CLI" color={pal.archive.accent} frame={frame} start={seg.builds[0] + 18} w={320} />
            <LabelChip text="BITBYBIT" color="#f1f6ff" frame={frame} start={seg.builds[0] + 36} w={250} idx={1} />
          </div>
          <div style={{position:'absolute', right:'12%', top:'40%', display:'flex', flexDirection:'column', gap:18}}>
            <LabelChip text="CREATIVE TOOLING" color="#f1f6ff" frame={frame} start={seg.builds[0] + 26} w={320} idx={2} />
            <LabelChip text="SYSTEMS" color={pal.archive.accent} frame={frame} start={seg.builds[0] + 46} w={220} idx={3} />
          </div>
          <div style={{position:'absolute', left:'50%', bottom:'22%', transform:'translateX(-50%)', textAlign:'center', opacity:clampFade(frame, seg.builds[0] + 44, seg.builds[1], 12)}}>
            <div style={{fontFamily:sans, fontSize:72, fontWeight:700, letterSpacing:'-0.05em', color:'#edf5fb'}}>BUILT LIKE</div>
            <div style={{fontFamily:sans, fontSize:84, fontWeight:700, letterSpacing:'-0.055em', background:pal.archive.accentGrad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'}}>A WORLD</div>
          </div>
        </div>
      )}

      {frame >= seg.final[0] && (
        <div style={{position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', opacity:clampFade(frame, seg.final[0], seg.final[1], 18), transform:`scale(${0.94 + finalSpring * 0.06}) translateY(${slideY(frame, seg.final[0], seg.final[0] + 18, 30)}px)`}}>
          <div style={{fontFamily:mono, fontSize:14, letterSpacing:'0.28em', color:pal.ocean.accent, textTransform:'uppercase', marginBottom:18}}>final signal</div>
          <div style={{fontFamily:sans, fontSize:118, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', color:'#edf7fc'}}>THANUKA</div>
          <div style={{fontFamily:sans, fontSize:118, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', background:pal.ocean.accentGrad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'}}>PERERA</div>
          <div style={{marginTop:24, fontFamily:mono, fontSize:16, letterSpacing:'0.12em', color:pal.ocean.subtle, textTransform:'uppercase'}}>GAME DEVELOPER · GPU ARCHITECTURE · SYSTEMS ENGINEER</div>
          <div style={{marginTop:18, fontFamily:mono, fontSize:22, letterSpacing:'0.06em', color:pal.ocean.accent}}>thanukamax.github.io</div>
        </div>
      )}
    </AbsoluteFill>
  );
};

const CenteredBlock: React.FC<{theme:any; frame:number; start:number; end:number; kicker:string; titleA:string; titleB:string; sub:string}> = ({theme, frame, start, end, kicker, titleA, titleB, sub}) => {
  return (
    <div style={{position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', opacity:clampFade(frame,start,end,16), transform:`translateY(${slideY(frame,start,start+12,24)}px)`}}>
      <div style={{fontFamily:mono, fontSize:14, letterSpacing:'0.28em', color:theme.accent, textTransform:'uppercase', marginBottom:18}}>{kicker}</div>
      <div style={{fontFamily:sans, fontSize:108, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', color:'#f4f8fb'}}>{titleA}</div>
      <div style={{fontFamily:sans, fontSize:108, lineHeight:0.9, fontWeight:700, letterSpacing:'-0.055em', background:theme.accentGrad, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text'}}>{titleB}</div>
      <div style={{marginTop:24, fontFamily:mono, fontSize:16, letterSpacing:'0.12em', color:theme.subtle, textTransform:'uppercase'}}>{sub}</div>
    </div>
  );
};
