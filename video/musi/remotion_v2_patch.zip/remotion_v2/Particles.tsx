
import React, {useMemo} from 'react';
import {AbsoluteFill, interpolate} from 'remotion';

type Mote = {x:number;y:number;size:number;speed:number;phase:number;alpha:number};

const motes = (count:number) => {
  const arr:Mote[] = [];
  for (let i=0;i<count;i++){
    const n = i * 97.231;
    arr.push({
      x:(n*3.7)%100,
      y:(n*6.2)%110,
      size:1 + ((n*1.1)%3.5),
      speed:0.4 + ((n*0.3)%1.2),
      phase:(n*0.5)%6.28,
      alpha:0.15 + ((n*0.2)%0.35),
    });
  }
  return arr;
};

export const Particles: React.FC<{frame:number; rdna:number}> = ({frame, rdna}) => {
  const items = useMemo(()=>motes(64), []);
  const rgb = rdna > 0.5 ? '255,82,92' : '124,224,255';
  const intro = interpolate(frame, [0, 20], [0, 1], {extrapolateRight:'clamp'});

  return (
    <AbsoluteFill style={{pointerEvents:'none', opacity:intro}}>
      {/* suspended silt */}
      {items.map((m, i) => {
        const rise = frame * (0.16 + m.speed * 0.08);
        const x = m.x + Math.sin(frame * 0.013 + m.phase) * (i % 4 === 0 ? 8 : 3);
        const y = ((m.y - rise) % 116 + 116) % 116 - 8;
        const op = m.alpha * (0.55 + Math.sin(frame * 0.03 + m.phase) * 0.2);

        return (
          <div
            key={i}
            style={{
              position:'absolute',
              left:`${x}%`,
              top:`${y}%`,
              width:m.size,
              height:m.size,
              borderRadius:'50%',
              background:`rgba(${rgb},${op})`,
              filter:'blur(0.4px)',
            }}
          />
        );
      })}

      {/* caustic sweep */}
      <div
        style={{
          position:'absolute',
          inset:'-10% -10% 0 -10%',
          background: `
            linear-gradient(115deg, transparent 10%, rgba(${rgb},0.04) 30%, transparent 52%),
            linear-gradient(95deg, transparent 18%, rgba(${rgb},0.02) 34%, transparent 60%)
          `,
          transform:`translateX(${Math.sin(frame * 0.012) * 120}px) translateY(${Math.cos(frame * 0.01) * 18}px)`,
          filter:'blur(8px)',
          opacity:0.55,
        }}
      />

      {/* pressure bloom */}
      <div
        style={{
          position:'absolute',
          left:'20%',
          right:'20%',
          bottom:'-6%',
          height:'36%',
          background:`radial-gradient(ellipse 70% 85% at 50% 100%, rgba(${rgb},0.12) 0%, rgba(${rgb},0.04) 36%, transparent 72%)`,
          filter:'blur(18px)',
          opacity:0.5,
        }}
      />

      {/* passing soft-focus foreground flecks */}
      {[0,1,2].map((i)=>(
        <div
          key={i}
          style={{
            position:'absolute',
            width: 120 + i*60,
            height: 24 + i*12,
            borderRadius: 999,
            background:`rgba(${rgb},${0.03 + i*0.01})`,
            top: `${18 + i*26}%`,
            left: `${-20 + ((frame * (0.25 + i*0.05)) % 140)}%`,
            filter:'blur(18px)',
            transform:`rotate(${i===1 ? -12 : 8}deg)`,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};
