
import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {FarBackground} from './FarBackground';
import {MidBackground} from './MidBackground';
import {TextPlane} from './TextPlane';
import {Foreground} from './Foreground';
import {Particles} from './Particles';

export const Trailer: React.FC = () => {
  const frame = useCurrentFrame();

  const rdna = interpolate(frame, [282, 290, 304, 314], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // make shots feel more like shots, not one endless zoom
  const camScale = interpolate(
    frame,
    [0, 96, 156, 228, 282, 320, 360],
    [1.08, 1.02, 1.04, 1.01, 1.06, 1.015, 1.0],
    {extrapolateRight: 'clamp'}
  );

  const camY = interpolate(
    frame,
    [0, 96, 156, 228, 282, 320, 360],
    [18, 0, -10, -4, -18, 0, 0],
    {extrapolateRight: 'clamp'}
  );

  const camX = interpolate(
    frame,
    [0, 100, 154, 222, 282, 320, 360],
    [0, -20, 18, 0, 10, 0, 0],
    {extrapolateRight: 'clamp'}
  );

  return (
    <AbsoluteFill style={{backgroundColor: '#01060f', overflow: 'hidden'}}>
      <Audio src={staticFile('music.mp3')} volume={0.9} />

      <AbsoluteFill style={{transform: `translate(${camX * 0.15}px, ${camY * 0.15}px) scale(${camScale * 1.02})`}}>
        <FarBackground frame={frame} rdna={rdna} />
      </AbsoluteFill>

      <AbsoluteFill style={{transform: `translate(${camX * 0.3}px, ${camY * 0.3}px) scale(${camScale * 1.04})`}}>
        <MidBackground frame={frame} rdna={rdna} />
      </AbsoluteFill>

      <AbsoluteFill style={{transform: `translate(${camX * 0.08}px, ${camY * 0.08}px) scale(${camScale})`}}>
        <TextPlane frame={frame} rdna={rdna} />
      </AbsoluteFill>

      <AbsoluteFill style={{transform: `translate(${camX * 0.45}px, ${camY * 0.45}px) scale(${camScale * 1.08})`}}>
        <Foreground frame={frame} rdna={rdna} />
      </AbsoluteFill>

      <Particles frame={frame} rdna={rdna} />

      {/* subtle RDNA flare */}
      <div
        style={{
          position:'absolute',
          inset:0,
          pointerEvents:'none',
          background:`radial-gradient(circle at 52% 45%, rgba(255,70,82,${rdna * 0.10}) 0%, transparent 34%)`,
          mixBlendMode:'screen',
        }}
      />

      {/* cinematic vignette */}
      <div
        style={{
          position:'absolute',
          inset:0,
          pointerEvents:'none',
          background:'radial-gradient(ellipse 70% 72% at 50% 45%, transparent 42%, rgba(1,6,15,0.18) 70%, rgba(1,6,15,0.60) 100%)',
        }}
      />

      {/* bottom pressure fog */}
      <div
        style={{
          position:'absolute',
          left:'-10%',
          right:'-10%',
          bottom:'-8%',
          height:'30%',
          pointerEvents:'none',
          background:'linear-gradient(180deg, transparent 0%, rgba(1,6,15,0.18) 35%, rgba(1,6,15,0.55) 100%)',
          filter:'blur(6px)',
        }}
      />
    </AbsoluteFill>
  );
};
