import React from 'react';
import {AbsoluteFill, interpolate, spring, useVideoConfig} from 'remotion';

export type Biome = 'ocean' | 'volcano' | 'forest' | 'mountain' | 'archive' | 'oceanFinal';

type Props = {
  biome: Biome;
  frame: number;
  opacity?: number;
};

const palettes: Record<Biome, {
  bg: string;
  glow: string;
  accent: string;
  dim: string;
  light: string;
}> = {
  ocean: {
    bg: '#030913',
    glow: '96,224,255',
    accent: '44,168,230',
    dim: '7,24,40',
    light: '176,240,255',
  },
  oceanFinal: {
    bg: '#02060f',
    glow: '125,235,255',
    accent: '65,188,240',
    dim: '8,25,44',
    light: '220,247,255',
  },
  volcano: {
    bg: '#100406',
    glow: '255,104,70',
    accent: '220,40,36',
    dim: '29,7,8',
    light: '255,185,120',
  },
  forest: {
    bg: '#07110b',
    glow: '118,255,163',
    accent: '46,185,94',
    dim: '10,25,15',
    light: '220,255,232',
  },
  mountain: {
    bg: '#08101b',
    glow: '187,215,255',
    accent: '111,162,230',
    dim: '13,20,38',
    light: '239,245,255',
  },
  archive: {
    bg: '#070910',
    glow: '142,209,255',
    accent: '106,130,255',
    dim: '10,14,26',
    light: '233,241,255',
  },
};

const lineColor = (rgb: string, alpha: number) => `rgba(${rgb},${alpha})`;

export const SceneBackground: React.FC<Props> = ({biome, frame, opacity = 1}) => {
  const {fps} = useVideoConfig();
  const pal = palettes[biome];
  const intro = spring({fps, frame: frame - 4, config: {damping: 200, stiffness: 100}});
  const driftX = Math.sin(frame * 0.012) * 20;
  const driftY = Math.cos(frame * 0.01) * 12;

  return (
    <AbsoluteFill style={{opacity, overflow: 'hidden'}}>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: buildBaseGradient(biome, pal),
        }}
      />

      {biome.startsWith('ocean') && <OceanScene pal={pal} frame={frame} intro={intro} driftX={driftX} driftY={driftY} />}
      {biome === 'volcano' && <VolcanoScene pal={pal} frame={frame} intro={intro} driftX={driftX} driftY={driftY} />}
      {biome === 'forest' && <ForestScene pal={pal} frame={frame} intro={intro} driftX={driftX} driftY={driftY} />}
      {biome === 'mountain' && <MountainScene pal={pal} frame={frame} intro={intro} driftX={driftX} driftY={driftY} />}
      {biome === 'archive' && <ArchiveScene pal={pal} frame={frame} intro={intro} driftX={driftX} driftY={driftY} />}

      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: `radial-gradient(ellipse 76% 72% at 50% 48%, transparent 40%, rgba(0,0,0,0.12) 68%, rgba(0,0,0,0.58) 100%)`,
        }}
      />
    </AbsoluteFill>
  );
};

const buildBaseGradient = (biome: Biome, pal: Props['biome'] extends never ? never : any) => {
  switch (biome) {
    case 'ocean':
    case 'oceanFinal':
      return `
        radial-gradient(ellipse 85% 65% at 50% 16%, rgba(${pal.glow},0.18) 0%, transparent 46%),
        radial-gradient(ellipse 120% 90% at 50% 105%, rgba(${pal.dim},0.98) 0%, ${pal.bg} 56%, #01040b 100%),
        linear-gradient(180deg, #06111d 0%, #04101a 26%, #030812 58%, #02060f 100%)
      `;
    case 'volcano':
      return `
        radial-gradient(ellipse 65% 45% at 50% 28%, rgba(${pal.glow},0.18) 0%, transparent 40%),
        radial-gradient(ellipse 110% 100% at 50% 100%, rgba(${pal.dim},0.98) 0%, ${pal.bg} 58%, #050102 100%),
        linear-gradient(180deg, #1a0608 0%, #120406 30%, #0b0204 65%, #040102 100%)
      `;
    case 'forest':
      return `
        radial-gradient(ellipse 70% 56% at 50% 18%, rgba(${pal.glow},0.12) 0%, transparent 44%),
        radial-gradient(ellipse 120% 90% at 50% 104%, rgba(${pal.dim},0.98) 0%, ${pal.bg} 56%, #030705 100%),
        linear-gradient(180deg, #09150d 0%, #08110b 28%, #050a07 64%, #030604 100%)
      `;
    case 'mountain':
      return `
        radial-gradient(ellipse 78% 50% at 50% 18%, rgba(${pal.glow},0.16) 0%, transparent 44%),
        radial-gradient(ellipse 120% 100% at 50% 104%, rgba(${pal.dim},0.98) 0%, ${pal.bg} 58%, #050912 100%),
        linear-gradient(180deg, #0b1525 0%, #0b1320 28%, #08101a 62%, #050913 100%)
      `;
    default:
      return `
        radial-gradient(ellipse 80% 56% at 50% 18%, rgba(${pal.glow},0.14) 0%, transparent 42%),
        radial-gradient(ellipse 120% 90% at 50% 104%, rgba(${pal.dim},0.98) 0%, ${pal.bg} 56%, #04060d 100%),
        linear-gradient(180deg, #090d18 0%, #080b15 28%, #060811 62%, #03050b 100%)
      `;
  }
};

const OceanScene: React.FC<any> = ({pal, frame, intro, driftX, driftY}) => {
  const finalMode = pal.bg === '#02060f';
  return (
    <>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          opacity: finalMode ? 0.75 : 0.55,
          background: `
            radial-gradient(circle at 18% 18%, rgba(${pal.glow},0.08) 0%, transparent 24%),
            radial-gradient(circle at 84% 24%, rgba(${pal.glow},0.08) 0%, transparent 22%),
            linear-gradient(110deg, transparent 0%, rgba(${pal.glow},0.03) 34%, transparent 56%),
            linear-gradient(72deg, transparent 12%, rgba(${pal.glow},0.02) 38%, transparent 64%)
          `,
          transform: `translate(${driftX * 0.18}px, ${driftY * 0.12}px)`,
          filter: 'blur(8px)',
        }}
      />

      {[18, 44, 72].map((x, idx) => (
        <div
          key={x}
          style={{
            position: 'absolute',
            top: '-8%',
            left: `${x}%`,
            width: 160 + idx * 28,
            height: '82%',
            transform: `translateX(${driftX * (0.1 + idx * 0.04)}px) skewX(${idx === 1 ? -6 : 5}deg)`,
            background: `linear-gradient(180deg, rgba(${pal.light},0.10) 0%, rgba(${pal.glow},0.04) 26%, transparent 78%)`,
            filter: 'blur(36px)',
            opacity: finalMode ? 0.85 : 0.55,
          }}
        />
      ))}

      <svg viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0, opacity: 0.62, transform: `translateY(${driftY * 0.2}px)`}}>
        <path d="M0 720 L120 684 L252 702 L380 656 L516 696 L662 640 L838 684 L990 630 L1166 688 L1316 638 L1478 684 L1620 648 L1766 694 L1920 670 L1920 1080 L0 1080 Z" fill="rgba(7,22,37,0.88)" />
      </svg>

      <div
        style={{
          position: 'absolute',
          top: '49%',
          left: '50%',
          width: finalMode ? 840 : 760,
          height: finalMode ? 840 : 760,
          transform: `translate(-50%, -50%) scale(${0.84 + intro * 0.16}) translateY(${driftY * 0.2}px)`,
          opacity: 0.24 + intro * 0.76,
        }}
      >
        <div style={{position: 'absolute', inset: 0, borderRadius: '50%', border: lineColor(pal.glow, finalMode ? 0.20 : 0.15), boxShadow: `0 0 80px rgba(${pal.glow},0.05)`}} />
        <div style={{position: 'absolute', inset: 42, borderRadius: '50%', border: lineColor(pal.glow, 0.10), transform: `rotate(${frame * 0.12}deg)`}} />
        <div style={{position: 'absolute', inset: 96, borderRadius: '50%', border: lineColor(pal.glow, 0.12), transform: `rotate(${-frame * 0.09}deg)`}} />
        <div style={{position: 'absolute', inset: 174, borderRadius: '50%', border: lineColor(pal.glow, 0.08)}} />
        <div style={{position: 'absolute', top: '50%', left: 120, right: 120, height: 1, background: lineColor(pal.glow, 0.08)}} />
        <div style={{position: 'absolute', left: '50%', top: 120, bottom: 120, width: 1, background: lineColor(pal.glow, 0.08)}} />
        <div style={{position: 'absolute', top: '50%', left: '50%', width: 20, height: 20, borderRadius: '50%', transform: 'translate(-50%, -50%)', background: `rgba(${pal.glow},1)`, boxShadow: `0 0 30px rgba(${pal.glow},0.7),0 0 90px rgba(${pal.glow},0.18)`}} />
      </div>
    </>
  );
};

const VolcanoScene: React.FC<any> = ({pal, frame, intro, driftX, driftY}) => {
  const glow = interpolate(Math.sin(frame * 0.04), [-1, 1], [0.08, 0.22]);
  return (
    <>
      <div style={{position: 'absolute', inset: 0, background: `radial-gradient(ellipse 55% 30% at 50% 42%, rgba(${pal.glow},${glow}) 0%, transparent 48%)`, filter: 'blur(10px)'}} />
      <div style={{position: 'absolute', inset: 0, background: `linear-gradient(180deg, transparent 0%, rgba(${pal.glow},0.04) 38%, transparent 64%)`, transform: `translateY(${driftY * 0.15}px)`, filter: 'blur(24px)'}} />
      <svg viewBox="0 0 1920 1080" style={{position: 'absolute', inset: 0, opacity: 0.76, transform: `translateY(${driftY * 0.18}px)`}}>
        <path d="M0 760 L140 724 L260 648 L352 706 L468 560 L548 632 L662 508 L758 598 L922 450 L1012 552 L1148 476 L1288 600 L1410 542 L1524 666 L1676 598 L1790 706 L1920 680 L1920 1080 L0 1080 Z" fill="rgba(15,4,6,0.94)" />
      </svg>
      {[0,1,2,3].map((i)=>(
        <div key={i} style={{position:'absolute', left:`${18 + i*18}%`, bottom:'12%', width:72 + i*16, height:380 + i*40, background:`linear-gradient(180deg, rgba(${pal.glow},0.02) 0%, rgba(${pal.dim},0.94) 28%, rgba(${pal.dim},0.98) 100%)`, clipPath:'polygon(40% 0, 72% 18%, 84% 40%, 100% 100%, 0 100%, 14% 52%, 20% 24%)', opacity:0.92, transform:`translateX(${driftX * (0.15 + i*0.03)}px)`}} />
      ))}
      <div style={{position:'absolute', top:'46%', left:'50%', width:620, height:620, transform:`translate(-50%, -50%) scale(${0.86 + intro*0.14})`, opacity:0.75}}>
        <div style={{position:'absolute', inset:0, borderRadius:'50%', border: lineColor(pal.glow,0.16), boxShadow:`0 0 90px rgba(${pal.glow},0.08)`}} />
        <div style={{position:'absolute', inset:54, borderRadius:'50%', border: lineColor(pal.glow,0.10), transform:`rotate(${frame*0.18}deg)`}} />
        <div style={{position:'absolute', inset:122, borderRadius:'50%', border: lineColor(pal.glow,0.08)}} />
        <div style={{position:'absolute', inset:'44% 44%', borderRadius:'50%', background:`rgba(${pal.glow},0.9)`, boxShadow:`0 0 36px rgba(${pal.glow},0.55),0 0 100px rgba(${pal.glow},0.15)`}} />
      </div>
    </>
  );
};

const ForestScene: React.FC<any> = ({pal, frame, driftX, driftY}) => {
  return (
    <>
      {[12, 26, 42, 58, 76, 88].map((x, idx) => (
        <div key={x} style={{position:'absolute', left:`${x}%`, bottom:'-6%', width:28 + (idx%2)*16, height:760 + idx*24, background:`linear-gradient(180deg, rgba(${pal.glow},0.02) 0%, rgba(${pal.dim},0.76) 22%, rgba(${pal.dim},0.98) 100%)`, opacity: idx>3 ? 0.7 : 0.92, transform:`translateX(${driftX * (0.08 + idx*0.02)}px)`, borderRadius:'18px 18px 0 0'}} />
      ))}
      <div style={{position:'absolute', inset:0, background:`radial-gradient(ellipse 80% 44% at 50% 20%, rgba(${pal.glow},0.12) 0%, transparent 52%)`}} />
      {[18, 40, 70].map((x, idx)=>(
        <div key={x} style={{position:'absolute', top:'-6%', left:`${x}%`, width:200, height:'72%', transform:`translateX(${driftX * (0.12+idx*0.04)}px) skewX(${idx===1?-4:4}deg)`, background:`linear-gradient(180deg, rgba(${pal.light},0.08) 0%, rgba(${pal.glow},0.03) 32%, transparent 76%)`, filter:'blur(30px)', opacity:0.6}} />
      ))}
      <svg viewBox="0 0 1920 1080" style={{position:'absolute', inset:0, opacity:0.58, transform:`translateY(${driftY * 0.16}px)`}}>
        <path d="M0 760 L160 700 L320 748 L476 680 L628 734 L786 692 L930 734 L1096 676 L1260 744 L1432 692 L1590 754 L1760 706 L1920 744 L1920 1080 L0 1080 Z" fill="rgba(7,16,10,0.78)"/>
      </svg>
    </>
  );
};

const MountainScene: React.FC<any> = ({pal, frame, intro, driftX}) => {
  return (
    <>
      <div style={{position:'absolute', inset:0, background:`linear-gradient(180deg, rgba(${pal.light},0.08) 0%, rgba(${pal.glow},0.03) 22%, transparent 58%)`, filter:'blur(18px)'}} />
      <svg viewBox="0 0 1920 1080" style={{position:'absolute', inset:0, opacity:0.88, transform:`translateX(${driftX*0.08}px)`}}>
        <path d="M0 820 L190 650 L334 730 L488 604 L642 746 L798 562 L978 770 L1142 610 L1310 772 L1498 586 L1688 760 L1828 694 L1920 760 L1920 1080 L0 1080 Z" fill="rgba(23,30,54,0.64)"/>
        <path d="M0 882 L250 708 L420 808 L612 678 L780 816 L1022 624 L1212 804 L1436 672 L1640 824 L1920 730 L1920 1080 L0 1080 Z" fill="rgba(13,18,34,0.88)"/>
      </svg>
      <div style={{position:'absolute', left:'50%', top:'38%', width:560, height:560, transform:`translate(-50%, -50%) scale(${0.9 + intro*0.1})`, opacity:0.54}}>
        <div style={{position:'absolute', inset:0, borderRadius:'50%', border: lineColor(pal.glow,0.11)}} />
        <div style={{position:'absolute', inset:58, borderRadius:'50%', border: lineColor(pal.glow,0.07)}} />
      </div>
    </>
  );
};

const ArchiveScene: React.FC<any> = ({pal, frame, intro, driftX, driftY}) => {
  return (
    <>
      <div style={{position:'absolute', inset:0, background:`radial-gradient(circle at 50% 24%, rgba(${pal.glow},0.15) 0%, transparent 34%)`}} />
      <div style={{position:'absolute', top:'49%', left:'50%', width:720, height:720, transform:`translate(-50%, -50%) scale(${0.88 + intro*0.12})`, opacity:0.66}}>
        <div style={{position:'absolute', inset:0, borderRadius:'50%', border: lineColor(pal.glow,0.12), boxShadow:`0 0 80px rgba(${pal.glow},0.05)`}} />
        <div style={{position:'absolute', inset:64, borderRadius:'50%', border: lineColor(pal.glow,0.09), transform:`rotate(${frame*0.16}deg)`}} />
        <div style={{position:'absolute', inset:128, borderRadius:'50%', border: lineColor(pal.glow,0.07), transform:`rotate(${-frame*0.08}deg)`}} />
      </div>
      {[0,1,2,3].map((i)=>(
        <div key={i} style={{position:'absolute', top:`${22 + i*12}%`, left:`${10 + i*16}%`, width:220 + i*40, height:54, border:`1px solid rgba(${pal.glow},${0.12 - i*0.02})`, background:`rgba(${pal.dim},0.24)`, borderRadius:14, filter:'blur(0.3px)', transform:`translate(${driftX * (0.08+i*0.02)}px, ${driftY * (0.05+i*0.02)}px)`}} />
      ))}
    </>
  );
};
