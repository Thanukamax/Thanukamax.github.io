import React, {useMemo} from 'react';
import {AbsoluteFill} from 'remotion';
import {Biome} from './SceneBackground';

type Props = {
  biome: Biome;
  frame: number;
  opacity?: number;
};

type Mote = {x:number;y:number;size:number;speed:number;phase:number;alpha:number};

const buildMotes = (count:number) => {
  const arr:Mote[] = [];
  for (let i=0;i<count;i++) {
    const n = i * 87.133;
    arr.push({
      x: (n * 3.1) % 100,
      y: (n * 5.7) % 110,
      size: 1 + ((n * 1.4) % 3.8),
      speed: 0.5 + ((n * 0.25) % 1.3),
      phase: (n * 0.44) % 6.28,
      alpha: 0.12 + ((n * 0.19) % 0.32),
    });
  }
  return arr;
};

const palette = (biome: Biome) => {
  switch (biome) {
    case 'ocean':
      return {rgb:'134,227,255', streak:'95,210,255'};
    case 'oceanFinal':
      return {rgb:'194,244,255', streak:'110,222,255'};
    case 'volcano':
      return {rgb:'255,118,82', streak:'255,70,60'};
    case 'forest':
      return {rgb:'144,255,170', streak:'86,224,122'};
    case 'mountain':
      return {rgb:'206,224,255', streak:'160,196,255'};
    default:
      return {rgb:'160,216,255', streak:'118,138,255'};
  }
};

export const Particles: React.FC<Props> = ({biome, frame, opacity = 1}) => {
  const items = useMemo(() => buildMotes(72), []);
  const pal = palette(biome);
  const speedFactor = biome === 'volcano' ? 1.15 : biome === 'forest' ? 0.72 : 0.9;

  return (
    <AbsoluteFill style={{opacity, pointerEvents:'none'}}>
      {items.map((m, i) => {
        const rise = frame * (0.15 + m.speed * 0.08) * speedFactor;
        const x = m.x + Math.sin(frame * 0.012 + m.phase) * (i % 5 === 0 ? 7 : 3);
        const y = ((m.y - rise) % 116 + 116) % 116 - 8;
        const op = m.alpha * (0.54 + Math.sin(frame * 0.03 + m.phase) * 0.24);
        return (
          <div
            key={i}
            style={{
              position:'absolute',
              left:`${x}%`,
              top:`${y}%`,
              width:m.size,
              height:m.size,
              borderRadius:'50%',
              background:`rgba(${pal.rgb},${op})`,
              filter:'blur(0.4px)',
            }}
          />
        );
      })}

      {biome === 'ocean' || biome === 'oceanFinal' ? <OceanBubbles frame={frame} pal={pal} /> : null}
      {biome === 'volcano' ? <FireParticles frame={frame} pal={pal} /> : null}
      {biome === 'forest' ? <FallingLeaves frame={frame} pal={pal} /> : null}
      {biome === 'mountain' ? <SnowDust frame={frame} pal={pal} /> : null}

      <div
        style={{
          position:'absolute',
          inset:'-12% -12% 0 -12%',
          background: `
            linear-gradient(112deg, transparent 4%, rgba(${pal.streak},0.04) 28%, transparent 52%),
            linear-gradient(90deg, transparent 18%, rgba(${pal.streak},0.025) 36%, transparent 62%)
          `,
          transform:`translateX(${Math.sin(frame * 0.011) * 120}px) translateY(${Math.cos(frame * 0.009) * 18}px)`,
          filter:'blur(10px)',
          opacity: biome === 'volcano' ? 0.45 : 0.58,
        }}
      />
    </AbsoluteFill>
  );
};

const OceanBubbles: React.FC<{frame:number; pal:{rgb:string; streak:string}}> = ({frame, pal}) => {
  return (
    <>
      {Array.from({length: 18}).map((_, i) => {
        const x = 8 + ((i * 17.3) % 84);
        const sway = Math.sin(frame * 0.02 + i) * (6 + (i % 3) * 3);
        const y = 102 - ((frame * (0.24 + (i % 5) * 0.04) + i * 19) % 120);
        const size = 8 + (i % 4) * 6;
        const alpha = 0.08 + (i % 3) * 0.04;
        return <div key={i} style={{position:'absolute', left:`calc(${x}% + ${sway}px)`, top:`${y}%`, width:size, height:size, borderRadius:'50%', border:`1px solid rgba(${pal.rgb},${alpha})`, boxShadow:`0 0 12px rgba(${pal.streak},${alpha * 0.6})`, background:`radial-gradient(circle at 35% 35%, rgba(255,255,255,0.22) 0%, rgba(${pal.rgb},0.02) 56%, transparent 72%)`, filter:'blur(0.2px)'}} />;
      })}
    </>
  );
};

const FireParticles: React.FC<{frame:number; pal:{rgb:string; streak:string}}> = ({frame, pal}) => {
  return (
    <>
      {Array.from({length: 26}).map((_, i) => {
        const x = 8 + ((i * 13.7) % 84);
        const y = 96 - ((frame * (0.38 + (i % 4) * 0.05) + i * 11) % 90);
        const drift = Math.sin(frame * 0.05 + i) * (10 + (i % 2) * 6);
        const size = 4 + (i % 3) * 4;
        const alpha = 0.14 + (i % 4) * 0.03;
        return <div key={i} style={{position:'absolute', left:`calc(${x}% + ${drift}px)`, top:`${y}%`, width:size, height:size * 1.6, borderRadius:'50% 50% 45% 45%', background:`radial-gradient(circle at 50% 20%, rgba(255,219,145,${alpha}) 0%, rgba(${pal.streak},${alpha}) 38%, rgba(${pal.rgb},0.02) 74%, transparent 100%)`, filter:'blur(0.5px)', transform:`rotate(${Math.sin(frame * 0.03 + i) * 22}deg)`}} />;
      })}
    </>
  );
};

const FallingLeaves: React.FC<{frame:number; pal:{rgb:string; streak:string}}> = ({frame, pal}) => {
  return (
    <>
      {Array.from({length: 18}).map((_, i) => {
        const x = 4 + ((i * 19.2) % 92);
        const y = -8 + ((frame * (0.28 + (i % 5) * 0.03) + i * 18) % 120);
        const drift = Math.sin(frame * 0.03 + i * 0.8) * (22 + (i % 3) * 6);
        const rotate = (frame * (0.9 + (i % 4) * 0.2) + i * 24) % 360;
        const s = 10 + (i % 4) * 4;
        return <div key={i} style={{position:'absolute', left:`calc(${x}% + ${drift}px)`, top:`${y}%`, width:s * 1.2, height:s * 0.7, background:`rgba(${pal.streak},${0.10 + (i % 3) * 0.03})`, clipPath:'polygon(50% 0, 100% 50%, 50% 100%, 0 50%)', filter:'blur(0.2px)', transform:`rotate(${rotate}deg)`}} />;
      })}
    </>
  );
};

const SnowDust: React.FC<{frame:number; pal:{rgb:string; streak:string}}> = ({frame, pal}) => {
  return (
    <>
      {Array.from({length: 28}).map((_, i) => {
        const x = 6 + ((i * 11.8) % 88);
        const y = -12 + ((frame * (0.22 + (i % 6) * 0.02) + i * 14) % 124);
        const drift = Math.sin(frame * 0.015 + i) * (14 + (i % 4) * 4);
        const size = 2 + (i % 4) * 2;
        return <div key={i} style={{position:'absolute', left:`calc(${x}% + ${drift}px)`, top:`${y}%`, width:size, height:size, borderRadius:'50%', background:`rgba(${pal.rgb},${0.12 + (i % 4) * 0.03})`, filter:'blur(0.2px)'}} />;
      })}
    </>
  );
};
