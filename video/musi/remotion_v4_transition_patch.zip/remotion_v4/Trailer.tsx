import React from 'react';
import {AbsoluteFill, Audio, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Biome, SceneBackground} from './SceneBackground';
import {SceneForeground} from './SceneForeground';
import {Particles} from './Particles';
import {TextOverlay} from './TextOverlay';

const sceneMap = [
  {start:0, end:90, biome:'ocean' as Biome},
  {start:90, end:180, biome:'ocean' as Biome},
  {start:180, end:300, biome:'archive' as Biome},
  {start:300, end:420, biome:'volcano' as Biome},
  {start:420, end:540, biome:'forest' as Biome},
  {start:540, end:660, biome:'mountain' as Biome},
  {start:660, end:780, biome:'archive' as Biome},
  {start:780, end:840, biome:'oceanFinal' as Biome},
];

const sceneOpacity = (frame:number, start:number, end:number, fadeIn=12, fadeOut=14) => {
  if (start === 0) {
    return interpolate(frame, [start, end - fadeOut, end], [1, 1, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
  }
  if (end === 840) {
    return interpolate(frame, [start, start + fadeIn, end], [0, 1, 1], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
  }
  return interpolate(frame, [start, start + fadeIn, end - fadeOut, end], [0, 1, 1, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
};

const pulse = (frame:number, center:number, width:number, amount:number) => {
  return interpolate(frame, [center - width, center, center + width], [0, amount, 0], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
};

const transitionBoundaries = [90, 180, 300, 420, 540, 660, 780];

const colorForBiome = (biome: Biome) => {
  switch (biome) {
    case 'ocean':
    case 'oceanFinal':
      return '98,224,255';
    case 'volcano':
      return '255,90,70';
    case 'forest':
      return '102,236,135';
    case 'mountain':
      return '192,214,255';
    default:
      return '121,150,255';
  }
};

const TransitionOverlay: React.FC<{frame:number; boundary:number; color:string; dir:number}> = ({frame, boundary, color, dir}) => {
  const op = pulse(frame, boundary, 14, 1);
  const travel = interpolate(frame, [boundary - 14, boundary + 14], [-72 * dir, 72 * dir], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
  const rotate = interpolate(frame, [boundary - 14, boundary + 14], [-6 * dir, 6 * dir], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
  return (
    <>
      <div
        style={{
          position:'absolute',
          inset:'-16% -24%',
          pointerEvents:'none',
          opacity:op * 0.85,
          transform:`translateX(${travel}%) rotate(${rotate}deg)`,
          background:`linear-gradient(90deg, transparent 0%, rgba(${color},0.02) 22%, rgba(${color},0.12) 50%, rgba(${color},0.02) 78%, transparent 100%)`,
          filter:'blur(34px)',
          mixBlendMode:'screen',
        }}
      />
      <div
        style={{
          position:'absolute',
          inset:0,
          pointerEvents:'none',
          opacity:op * 0.22,
          background:`radial-gradient(circle at 50% 50%, rgba(${color},0.22) 0%, transparent 46%)`,
          filter:'blur(20px)',
          mixBlendMode:'screen',
        }}
      />
    </>
  );
};

const OccluderWipe: React.FC<{frame:number; boundary:number; dir:number}> = ({frame, boundary, dir}) => {
  const op = pulse(frame, boundary, 12, 1);
  const x = interpolate(frame, [boundary - 10, boundary + 10], [-130 * dir, 130 * dir], {extrapolateLeft:'clamp', extrapolateRight:'clamp'});
  return (
    <div
      style={{
        position:'absolute',
        top:'-10%',
        left:'-25%',
        width:'150%',
        height:'120%',
        opacity:op * 0.4,
        transform:`translateX(${x}%) rotate(${dir * 11}deg)`,
        background:'linear-gradient(90deg, transparent 0%, rgba(1,4,10,0.0) 10%, rgba(1,4,10,0.88) 48%, rgba(1,4,10,0.0) 88%, transparent 100%)',
        filter:'blur(6px)',
        pointerEvents:'none',
      }}
    />
  );
};

export const Trailer: React.FC = () => {
  const frame = useCurrentFrame();

  const driftX = Math.sin(frame * 0.01) * 6;
  const driftY = Math.cos(frame * 0.008) * 4;
  const push = interpolate(frame, [0, 840], [1.018, 1.0], {extrapolateRight:'clamp'});
  const whipX = transitionBoundaries.reduce((acc, boundary, idx) => acc + pulse(frame, boundary, 12, idx % 2 === 0 ? -48 : 48), 0);
  const whipY = transitionBoundaries.reduce((acc, boundary) => acc + pulse(frame, boundary, 14, -14), 0);
  const whipRot = transitionBoundaries.reduce((acc, boundary, idx) => acc + pulse(frame, boundary, 12, idx % 2 === 0 ? -1.8 : 1.8), 0);
  const zoomBurst = transitionBoundaries.reduce((acc, boundary) => acc + pulse(frame, boundary, 14, 0.04), 0);

  return (
    <AbsoluteFill style={{backgroundColor:'#02060f', overflow:'hidden'}}>
      <Audio src={staticFile('music.mp3')} volume={0.92} />

      <AbsoluteFill style={{transform:`translate(${driftX + whipX * 0.22}px, ${driftY + whipY * 0.18}px) scale(${push + zoomBurst * 0.45}) rotate(${whipRot * 0.16}deg)`}}>
        {sceneMap.map((scene) => {
          const localFrame = Math.max(0, frame - scene.start);
          const opacity = sceneOpacity(frame, scene.start, scene.end);
          return (
            <AbsoluteFill key={`${scene.start}-${scene.biome}`}>
              <SceneBackground biome={scene.biome} frame={localFrame} opacity={opacity} />
            </AbsoluteFill>
          );
        })}
      </AbsoluteFill>

      <AbsoluteFill style={{transform:`translate(${driftX * 0.72 + whipX * 0.48}px, ${driftY * 0.46 + whipY * 0.32}px) rotate(${whipRot * 0.32}deg)`}}>
        {sceneMap.map((scene) => {
          const localFrame = Math.max(0, frame - scene.start);
          const opacity = sceneOpacity(frame, scene.start, scene.end);
          return (
            <AbsoluteFill key={`p-${scene.start}-${scene.biome}`}>
              <Particles biome={scene.biome} frame={localFrame} opacity={opacity} />
            </AbsoluteFill>
          );
        })}
      </AbsoluteFill>

      <AbsoluteFill style={{transform:`translate(${driftX * 0.24 + whipX * 0.12}px, ${driftY * 0.16 + whipY * 0.1}px) scale(${1 + zoomBurst * 0.08})`}}>
        <TextOverlay frame={frame} />
      </AbsoluteFill>

      <AbsoluteFill style={{transform:`translate(${driftX * 0.92 + whipX * 0.78}px, ${driftY * 0.58 + whipY * 0.48}px) scale(${1.03 + zoomBurst * 0.2}) rotate(${whipRot * 0.46}deg)`}}>
        {sceneMap.map((scene) => {
          const localFrame = Math.max(0, frame - scene.start);
          const opacity = sceneOpacity(frame, scene.start, scene.end);
          return (
            <AbsoluteFill key={`f-${scene.start}-${scene.biome}`}>
              <SceneForeground biome={scene.biome} frame={localFrame} opacity={opacity} />
            </AbsoluteFill>
          );
        })}
      </AbsoluteFill>

      {transitionBoundaries.map((boundary, idx) => {
        const nextBiome = sceneMap.find((scene) => scene.start === boundary)?.biome ?? 'ocean';
        const dir = idx % 2 === 0 ? 1 : -1;
        return <React.Fragment key={boundary}><TransitionOverlay frame={frame} boundary={boundary} color={colorForBiome(nextBiome)} dir={dir} /><OccluderWipe frame={frame} boundary={boundary} dir={dir} /></React.Fragment>;
      })}

      <div style={{position:'absolute', inset:0, background:'radial-gradient(ellipse 78% 72% at 50% 46%, transparent 36%, rgba(1,4,10,0.16) 66%, rgba(1,4,10,0.52) 100%)', pointerEvents:'none'}} />
      <div style={{position:'absolute', inset:'auto -8% -8% -8%', height:'30%', background:'linear-gradient(180deg, transparent 0%, rgba(1,4,10,0.16) 30%, rgba(1,4,10,0.58) 100%)', filter:'blur(8px)', pointerEvents:'none'}} />
    </AbsoluteFill>
  );
};
