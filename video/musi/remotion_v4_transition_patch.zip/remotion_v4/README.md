# remotion_v3

28-second multi-biome trailer rebuild.

## What changed
- Extended from 12s to 28s (`840` frames @ `30fps`)
- Multiple environments instead of one scene with text swaps
- Ocean intro/finale, volcanic RDNA, forest CUDA, mountain tech stack, archive/proof montage
- New foreground per biome (corals, basalt, trees, ridges, archive slabs)
- Faster scene energy with wipes/swing pulses at boundaries
- Bigger text and longer readable holds

## Files
- `index.ts`
- `Root.tsx`
- `Trailer.tsx`
- `SceneBackground.tsx`
- `SceneForeground.tsx`
- `Particles.tsx`
- `TextOverlay.tsx`

## Required audio
Put your chosen track here:

`public/music.mp3`

The composition expects `staticFile('music.mp3')`.

## Render
If these files live in `src/`:

```bash
npx remotion render src/index.ts Trailer out/trailer-v3.mp4 --codec=h264
```

If they live in the project root:

```bash
npx remotion render index.ts Trailer out/trailer-v3.mp4 --codec=h264
```

## Preview
```bash
npx remotion studio src/index.ts
```
