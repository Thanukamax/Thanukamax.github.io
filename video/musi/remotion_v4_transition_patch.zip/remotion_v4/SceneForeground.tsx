import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {Biome} from './SceneBackground';

type Props = {
  biome: Biome;
  frame: number;
  opacity?: number;
};

const baseColor = (biome: Biome) => {
  switch (biome) {
    case 'ocean':
    case 'oceanFinal':
      return '2,8,18';
    case 'volcano':
      return '20,4,6';
    case 'forest':
      return '6,16,8';
    case 'mountain':
      return '8,12,24';
    default:
      return '7,9,18';
  }
};

export const SceneForeground: React.FC<Props> = ({biome, frame, opacity = 1}) => {
  const base = baseColor(biome);
  const leftIn = interpolate(frame, [0, 18], [-70, 0], {extrapolateRight: 'clamp'});
  const rightIn = interpolate(frame, [0, 18], [70, 0], {extrapolateRight: 'clamp'});
  const float = Math.sin(frame * 0.016) * 8;

  return (
    <AbsoluteFill style={{opacity, pointerEvents: 'none', overflow: 'hidden'}}>
      {biome.startsWith('ocean') && <OceanForeground base={base} leftIn={leftIn} rightIn={rightIn} float={float} />}
      {biome === 'volcano' && <VolcanoForeground base={base} leftIn={leftIn} rightIn={rightIn} float={float} />}
      {biome === 'forest' && <ForestForeground base={base} leftIn={leftIn} rightIn={rightIn} float={float} />}
      {biome === 'mountain' && <MountainForeground base={base} leftIn={leftIn} rightIn={rightIn} float={float} />}
      {biome === 'archive' && <ArchiveForeground base={base} leftIn={leftIn} rightIn={rightIn} float={float} />}

      <div style={{position:'absolute', inset:0, boxShadow:`inset 0 0 140px rgba(${base},0.38)`}} />
    </AbsoluteFill>
  );
};

const OceanForeground: React.FC<any> = ({base, leftIn, rightIn, float}) => (
  <>
    <svg viewBox="0 0 620 1080" style={{position:'absolute', left:-70, bottom:-10, width:620, height:1080, transform:`translateX(${leftIn}px) translateY(${float * 0.5}px)`}}>
      <path d="M0 1080 L0 540 L66 500 L98 448 L132 394 L180 358 L228 330 L248 288 L296 260 L330 290 L352 340 L344 400 L390 460 L456 536 L520 1080 Z" fill={`rgba(${base},0.97)`} />
      <path d="M184 620 C170 566 194 516 228 492 C254 474 286 486 290 520 C294 560 266 612 228 646 Z" fill={`rgba(${base},0.74)`} />
      <path d="M96 724 C102 666 134 624 170 620 C202 616 220 650 210 700 C200 746 164 786 128 786 C104 786 90 764 96 724 Z" fill={`rgba(${base},0.84)`} />
      <path d="M260 764 C272 714 308 694 338 706 C368 718 370 760 350 810 C330 856 294 884 270 870 C248 856 244 816 260 764 Z" fill={`rgba(${base},0.80)`} />
    </svg>

    <svg viewBox="0 0 620 1080" style={{position:'absolute', right:-70, bottom:-10, width:620, height:1080, transform:`translateX(${rightIn}px) translateY(${float * -0.42}px)`}}>
      <path d="M620 1080 L620 536 L564 492 L520 430 L484 372 L444 338 L394 304 L362 268 L312 252 L286 286 L278 338 L306 390 L272 450 L214 530 L146 1080 Z" fill={`rgba(${base},0.97)`} />
      <path d="M360 616 C366 566 392 518 430 496 C458 480 480 498 482 528 C484 564 456 612 412 646 Z" fill={`rgba(${base},0.74)`} />
      <path d="M438 758 C432 704 404 676 372 680 C338 684 322 720 332 768 C342 818 374 852 408 850 C430 848 444 814 438 758 Z" fill={`rgba(${base},0.82)`} />
    </svg>

    <svg viewBox="0 0 1920 300" style={{position:'absolute', left:0, bottom:-10, width:'100%', height:300, opacity:0.84}}>
      <path d="M0 300 L0 174 L124 158 L190 132 L250 144 L324 112 L428 150 L542 118 L664 154 L780 122 L914 160 L1042 128 L1178 162 L1322 132 L1452 168 L1582 146 L1710 172 L1838 158 L1920 176 L1920 300 Z" fill={`rgba(${base},0.86)`} />
    </svg>
  </>
);

const VolcanoForeground: React.FC<any> = ({base, leftIn, rightIn, float}) => (
  <>
    {[0,1,2].map((i)=>(
      <div key={i} style={{position:'absolute', left:`${-2 + i*14}%`, bottom:`${8 + i*2}%`, width:180 + i*30, height:440 + i*70, background:`rgba(${base},0.96)`, clipPath:'polygon(46% 0, 72% 18%, 90% 40%, 100% 100%, 0 100%, 12% 56%, 20% 22%)', transform:`translateX(${leftIn * (0.65 + i*0.12)}px) translateY(${float * (0.4+i*0.05)}px)`}} />
    ))}
    {[0,1,2].map((i)=>(
      <div key={i} style={{position:'absolute', right:`${-1 + i*13}%`, bottom:`${7 + i*3}%`, width:180 + i*34, height:420 + i*80, background:`rgba(${base},0.96)`, clipPath:'polygon(42% 0, 68% 18%, 84% 44%, 100% 100%, 0 100%, 14% 54%, 18% 24%)', transform:`translateX(${rightIn * (0.62 + i*0.1)}px) translateY(${float * (-0.36-i*0.04)}px)`}} />
    ))}
    <svg viewBox="0 0 1920 260" style={{position:'absolute', left:0, bottom:-8, width:'100%', height:260, opacity:0.86}}>
      <path d="M0 260 L0 176 L124 168 L252 122 L316 138 L418 80 L540 160 L658 92 L786 182 L940 88 L1096 170 L1248 106 L1410 182 L1562 114 L1710 172 L1824 146 L1920 166 L1920 260 Z" fill={`rgba(${base},0.90)`} />
    </svg>
  </>
);

const ForestForeground: React.FC<any> = ({base, leftIn, rightIn, float}) => (
  <>
    {[8,20,34,74,88].map((x, idx)=>(
      <div key={x} style={{position:'absolute', left:`${x}%`, bottom:'-6%', width:40 + (idx%2)*26, height:840 - idx*34, background:`rgba(${base},0.96)`, transform:`translateX(${idx<3?leftIn:rightIn}px) translateY(${float * (idx%2===0?0.36:-0.32)}px)`, borderRadius:'22px 22px 0 0'}} />
    ))}
    <svg viewBox="0 0 480 1080" style={{position:'absolute', left:-30, bottom:-10, width:480, height:1080, opacity:0.9}}>
      <path d="M0 1080 L0 660 L90 642 L128 594 L166 530 L196 482 L246 456 L268 494 L254 542 L284 604 L324 656 L364 1080 Z" fill={`rgba(${base},0.88)`} />
    </svg>
    <svg viewBox="0 0 480 1080" style={{position:'absolute', right:-30, bottom:-10, width:480, height:1080, opacity:0.9}}>
      <path d="M480 1080 L480 632 L426 616 L390 566 L348 498 L314 462 L258 442 L238 478 L250 532 L218 608 L178 660 L136 1080 Z" fill={`rgba(${base},0.88)`} />
    </svg>
    <div style={{position:'absolute', inset:'auto 0 -2% 0', height:'26%', background:`linear-gradient(180deg, transparent 0%, rgba(${base},0.34) 22%, rgba(${base},0.84) 100%)`}} />
  </>
);

const MountainForeground: React.FC<any> = ({base, leftIn, rightIn, float}) => (
  <>
    <svg viewBox="0 0 1920 320" style={{position:'absolute', left:0, bottom:-6, width:'100%', height:320, opacity:0.92}}>
      <path d="M0 320 L0 188 L160 144 L306 194 L450 118 L584 206 L760 108 L924 220 L1128 102 L1284 214 L1464 124 L1644 226 L1820 166 L1920 194 L1920 320 Z" fill={`rgba(${base},0.92)`} />
    </svg>
    <div style={{position:'absolute', left:'-3%', bottom:'6%', width:320, height:340, background:`rgba(${base},0.96)`, clipPath:'polygon(0 100%, 18% 56%, 40% 36%, 52% 20%, 66% 0, 82% 42%, 100% 100%)', transform:`translateX(${leftIn * 0.6}px) translateY(${float * 0.34}px)`}} />
    <div style={{position:'absolute', right:'-3%', bottom:'7%', width:340, height:320, background:`rgba(${base},0.96)`, clipPath:'polygon(0 100%, 16% 48%, 42% 20%, 56% 0, 70% 34%, 86% 58%, 100% 100%)', transform:`translateX(${rightIn * 0.6}px) translateY(${float * -0.28}px)`}} />
  </>
);

const ArchiveForeground: React.FC<any> = ({base, leftIn, rightIn, float}) => (
  <>
    <div style={{position:'absolute', left:'4%', top:'12%', width:180, height:760, border:`1px solid rgba(144,210,255,0.08)`, background:`rgba(${base},0.36)`, borderRadius:30, transform:`translateX(${leftIn * 0.5}px) translateY(${float * 0.2}px)`}} />
    <div style={{position:'absolute', right:'4%', top:'16%', width:180, height:720, border:`1px solid rgba(144,210,255,0.08)`, background:`rgba(${base},0.36)`, borderRadius:30, transform:`translateX(${rightIn * 0.5}px) translateY(${float * -0.18}px)`}} />
    <svg viewBox="0 0 1920 220" style={{position:'absolute', left:0, bottom:-6, width:'100%', height:220, opacity:0.80}}>
      <path d="M0 220 L0 156 L160 138 L292 124 L436 146 L602 112 L742 148 L932 114 L1084 146 L1244 110 L1418 150 L1606 120 L1764 148 L1920 136 L1920 220 Z" fill={`rgba(${base},0.84)`} />
    </svg>
  </>
);
